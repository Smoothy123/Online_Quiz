<?php
session_start();
require_once "connection.php";

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

// Fetch quiz marks from the database
$query = "SELECT username, score FROM quiz_marks ORDER BY score DESC";
$result = mysqli_query($connection, $query);

// Check if there are any quiz marks
if (mysqli_num_rows($result) > 0) {
    echo "<h2>Quiz Rankings</h2>";
    echo "<table border='1'>";
    echo "<tr><th>Rank</th><th>Username</th><th>Score</th></tr>";
    $rank = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $rank++ . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['score'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No quiz marks found.";
}
?>
