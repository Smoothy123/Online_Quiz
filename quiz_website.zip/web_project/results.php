<?php
session_start();
require_once "connection.php";

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

// Initialize score
$score = 0;

// Retrieve submitted answers
if (isset($_POST['answers'])) {
    $submittedAnswers = $_POST['answers'];

    // Loop through submitted answers
    foreach ($submittedAnswers as $questionId => $submittedAnswer) {
        // Retrieve correct answer from database
        $query = "SELECT correct_answer FROM questions WHERE id = $questionId";
        $result = mysqli_query($connection, $query);
        $row = mysqli_fetch_assoc($result);
        $correctAnswer = $row['correct_answer'];

        // Check if submitted answer is correct
        if ($submittedAnswer === $correctAnswer) {
            $score++;
        }
    }

    // Update user's score and latest completion time
    $username = $_SESSION['user'];
    $currentTime = date('Y-m-d H:i:s');
    $updateQuery = "UPDATE users SET score = $score, completion_time = NOW() WHERE username = '$username'";
    mysqli_query($connection, $updateQuery);
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Quiz Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 100px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #333;
        }

        .score {
            font-size: 24px;
            color: #007bff;
        }

        .home-link {
            display: block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Quiz Results</h2>
        <p class="score">Your score: <?php echo $score; ?></p>
        <a href="home.php" class="home-link">Go to Home Page</a>
    </div>
</body>
</html>
