<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['user'];
$role = isset($_SESSION['role']) ? $_SESSION['role'] : ''; 

if ($role === 'admin') {
    $greeting = "Welcome, Admin $username!";
} else {
    $greeting = "Welcome, $username!";
    $startQuizLink = "quiz.php"; 
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <style>
        body {
            background-image:url("https://th.bing.com/th/id/OIP.7QlwlHZk9lPmoAKMbLXcqQHaFW?rs=1&pid=ImgDetMain");
             background-size: 1500px 1100px ;
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        h2 {
            color: #343a40;
            text-align: center;
            margin-top: 50px;
        }

        .quiz-link, .logout-link, .profile-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
            font-weight: bold;
            cursor: pointer;
        }

        .quiz-link {
            background-color: #007bff;
            color: #fff;
        }

        .quiz-link:hover {
            background-color: #0056b3;
        }

        .logout-link {
            background-color: #dc3545;
            color: #fff;
        }

        .logout-link:hover {
            background-color: #bd2130;
        }

        .profile-link {
            background-color: #ffc107;
            color: #333;
        }

        .profile-link:hover {
            background-color: #e0a800;
        }
    </style>
</head>
<body>
    <h2><?php echo $greeting; ?></h2>
    <a href="<?php echo $startQuizLink; ?>" class="quiz-link">Start Quiz</a>
    <a href="logout.php" class="logout-link">Logout</a>
    <a href="edit_profile.php" class="profile-link">Edit Profile</a>
</body>
</html>
