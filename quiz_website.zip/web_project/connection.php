<?php
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "hello"; 

$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
function authenticateAdmin($username, $password, $connection) {
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password' AND is_admin = 1";
    $result = mysqli_query($connection, $query);
    return mysqli_num_rows($result) == 1;
}

?>
